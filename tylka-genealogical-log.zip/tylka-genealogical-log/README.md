# Tylka Genealogical Log

A clean, responsive starting point for a family-history website with a restrained antique-parchment palette, traditional serif typography, fine rules, and subtle motion. No gradients and no Netlify dependencies.

## Files
- `index.html` — home page and project overview
- `archive.html` — seven record-collection sections with a client-side folder search
- `styles.css` — design system, responsive layout, reduced-motion support
- `script.js` — mobile navigation, scroll reveals, and collection filtering

## Design principles
- Warm parchment, ink, and muted brown colors; flat color surfaces only
- Smooth, restrained transitions and scroll reveals
- Responsive navigation and layouts
- Accessible focus styles and reduced-motion preference support

## Current status and important limitations
This is a front-end starter project. The archive collections are placeholders; they do not yet store uploaded files or record metadata. There is no owner authentication or persistent database in this starter, intentionally avoiding any Netlify-specific backend.

Before enabling public uploads or owner-only editing, choose and configure a replacement backend and hosting provider. Add server-side authentication and persistent storage before publishing private owner controls. Do not put passwords, API keys, or owner codes in browser-side code.

## Run locally
Open `index.html` in a browser, or serve this folder with any basic local static HTTP server.

## Deploy
This project is static HTML/CSS/JavaScript and does not require a build step. It can be deployed to a static host that supports plain files. No Netlify configuration is included.
